import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import openai
import os
import speech_recognition as sr

#openai api
OPENAI_API_KEY = "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"
openai.api_key = OPENAI_API_KEY

window = tk.Tk()
window.title("Baymax Voice Assistant")
window.geometry("400x569")
window.configure(bg="#66D1D1")

# Load Baymax Image
try:
    baymax_image = tk.PhotoImage(file="icons/baymax_background.png") #Замените на свой если будет нужно
except tk.TclError as e:
    print(f"Error loading Baymax image: {e}")
    baymax_image = None

# Create a label to hold the image and scale it
image_label = tk.Label(window, image=baymax_image, bg="#66D1D1")
image_label.place(x=0, y=0, relwidth=1, relheight=1)

# Button (Styled like Baymax's chest symbol)
try:
    button_image = tk.PhotoImage(file="icons/baymax_button.png")
except tk.TclError as e:
    print(f"Error loading button image: {e}")
    button_image = None


#logo
try:
    logo_image = Image.open("icons/logo.png")
    logo_image = logo_image.resize((76, 50))  # Resize the image to 50x50 pixels
    logo_image = ImageTk.PhotoImage(logo_image)
except Exception as e:
    print(f"Error loading logo image: {e}")
    logo_image = None

logo_label = tk.Label(window, image=logo_image, bg="#9AD5C2")
logo_label.image = logo_image  # Keep a reference to the image
logo_label.place(x=10, y=10)

#text
text_label = tk.Label(window, text="Baymax Voice Assistant", font=("Arial", 20), bg="#9AD5C2", fg="#FFFFFF")
text_label.place(x=94, y=20)

#btn my version 
button_image = tk.PhotoImage(file="icons/microphone.png")  # Replace with your image file
button = tk.Button(window, image=button_image, bg="#FFFFFF", activebackground="#FFFFFF", bd=0, width=40, height=40,
                   highlightthickness=0)  # Set highlightthickness to 0 for transparent background
button.image = button_image  # Keep a reference to the image
button.place(relx=0.5, rely=0.5, anchor=tk.CENTER)  # Center the button



#output window
output_window = tk.Text(window, width=40, height=4.8, font=("Arial", 12))
output_window.pack(side=tk.BOTTOM, fill=tk.X, pady=10)


# Text Entry Area (Mimicking Baymax's Belly Screen)
entry = ttk.Entry(
    window,
    width=20,  # Narrower entry
    font=("Arial", 12),  # Smaller font
    foreground="black",
    background="#2F80ED"
)
entry.place(relx=0.46, rely=0.80, anchor="center")  # Adjusted entry position


#button to send the text

button2 = tk.Button(window, border = None , text="Send", width=5, height=1, font=("Arial", 8), bg="#3F53E0", fg="white")
button2.place(relx=0.74, rely=0.80, anchor="center")


# Define a function to send the user's query to the GPT API and display the response
def get_response(event=None):
    user_query = entry.get()
    try:
        response = openai.Completion.create(
            engine="gpt-3.5-turbo-instruct",
            prompt=user_query,
            max_tokens=1024,
            temperature=0.5,
        )
        output_window.insert(tk.END, "You: " + user_query + "\n")
        output_window.insert(tk.END, "Baymax: " + response.choices[0].text + "\n")
        entry.delete(0, tk.END)  # Clear the entry field
    except openai.error.APIError as e:
        print(f"API Error: {e}")
    except openai.error.RateLimitError as e:
        print(f"Rate Limit Error: {e}")
    except Exception as e:
        print(f"Error: {e}")
# Define a func handle speech 
def speech_to_text():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        audio = r.listen(source)
        try:
            text = r.recognize_google(audio, language="en-US")
            entry.delete(0, tk.END)
            entry.insert(0, text)
        except sr.UnknownValueError:
            print("Speech recognition could not understand your audio")
        except sr.RequestError as e:
            print("Could not request results from speech recognition service; {0}".format(e))

button.config(command=speech_to_text)

button2.config(command=get_response)

window.mainloop()

